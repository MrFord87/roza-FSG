export default function Header() {
  return (
    <div style={{ padding: '1rem', borderBottom: '1px solid #333' }}>
      <h2>Hello, Antoine 👋🏾</h2>
    </div>
  );
}
