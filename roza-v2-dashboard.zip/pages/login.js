export default function Login() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: '#111', color: '#fff' }}>
      <div>
        <h1>Login to Roza</h1>
        <input placeholder="Enter your team code" style={{ padding: '0.5rem', marginTop: '1rem', width: '100%' }} />
      </div>
    </div>
  );
}
